export class User {
    id:number | undefined;
    first_name:string | undefined;
    last_name:string | undefined;
    email:string | undefined;
    password:string | undefined;
    role:string | undefined;
    gender:string | undefined;
    constructor(){}
}
