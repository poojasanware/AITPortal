export class News {
    id!: number;
    news!: string;
    title!: string;
    createdDate!: Date;
    modifiedDate!: Date;
    constructor(){}
}
