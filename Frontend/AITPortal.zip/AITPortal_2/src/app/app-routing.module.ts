import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './modules/signup/signup.component';
import { AdduserComponent } from './modules/adduser/adduser.component';
import { AddeventComponent } from './modules/addevent/addevent.component';
import { HeaderComponent } from './modules/header/header.component';
import { CactivateGuard } from './guards/cactivate.guard';
import { AddnewsComponent } from './modules/addnews/addnews.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { FooterComponent } from './modules/footer/footer.component';
import { SidebarComponent } from './modules/sidebar/sidebar.component';
import { CalenderComponent } from './modules/calender/calender.component';
import { NewsComponent } from './modules/news/news.component';
import { CommondashboardComponent } from './modules/commondashboard/commondashboard.component';
import { EditnewsComponent } from './modules/editnews/editnews.component';
import { UpdateeventComponent } from './modules/updateevent/updateevent.component';
import { EventlistComponent } from './modules/eventlist/eventlist.component';
import { PagenotfoundComponent } from './modules/pagenotfound/pagenotfound.component';

const routes: Routes = [
  { path: '', redirectTo: 'commondashboard', pathMatch: 'full' },
  { component: CommondashboardComponent, path: "commondashboard" },
  { component: SignupComponent, path: "signin" },

  { path: 'dashboard', component: DashboardComponent, canActivate: [CactivateGuard] },
  { path: 'sidebar', component: SidebarComponent, canActivate: [CactivateGuard] },
  { path: 'header', component: HeaderComponent, canActivate: [CactivateGuard] },
  { path: 'footer', component: FooterComponent, canActivate: [CactivateGuard] },
  { path: 'calender', component: CalenderComponent, canActivate: [CactivateGuard] },
  { path: 'news', component: NewsComponent, canActivate: [CactivateGuard] },
  { path: 'adduser', component: AdduserComponent, canActivate: [CactivateGuard] },
  { path: 'addevent', component: AddeventComponent, canActivate: [CactivateGuard] },
  { path: 'addnews', component: AddnewsComponent, canActivate: [CactivateGuard] },
  { path: 'commondashboard/editnews/:id', component: EditnewsComponent, canActivate: [CactivateGuard] },
  { path: 'eventlist/updateevent/:id', component: UpdateeventComponent, canActivate: [CactivateGuard] },
  { path: 'eventlist', component: EventlistComponent, canActivate: [CactivateGuard] },
  { path: '**', component: PagenotfoundComponent },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
