import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  xyz: any;
  role: any;
  uname: any;
  constructor(private router: Router) { }

  ngOnInit(): void {
    this.xyz = localStorage.getItem('first_name');
    this.role = localStorage.getItem('role');
    this.uname = localStorage.getItem('uname');
    console.log(this.uname);
  }
  dashboard() {
    this.router.navigate(["commondashboard"]);
  }


  LogoutUser() {
    localStorage.clear();
    console.log("logout successfull")
    this.router.navigate(["signin"]);
  }
  myimage3: string = "assets/aitlogo.png";


  SignIn() {
    this.router.navigate(["signin"]);
  }
}