import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { Event } from 'src/app/classes/event';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-eventlist',
  templateUrl: './eventlist.component.html',
  styleUrls: ['./eventlist.component.css']
})
export class EventlistComponent implements OnInit {
  event = new Event();
  searchedKeyword: any;
  p: number | undefined;

  constructor(private emp: CommonService, private router: Router) { }
  lstevent: Event[] = [];

  ngOnInit(): void {
    this.getAllEvent();
  }

  getAllEvent() {
    this.emp.getAllEvent().subscribe(
      data => {
        this.lstevent = data;
        console.log(this.lstevent);
      }
    );
  }

  deleteEvent(lstevent: Event) {
    if (confirm('Are you sure to delete??')) {
      this.emp.deletEvent(lstevent).subscribe(() => {
        Swal.fire('Success', 'Deleted Successfully', 'success');
        this.getAllEvent();
      })
    }
  }

  key: string = 'id';
  reverse: boolean = false;
  sort(key: string) {
    this.key = key;
    this.reverse = !this.reverse;
  }

}
