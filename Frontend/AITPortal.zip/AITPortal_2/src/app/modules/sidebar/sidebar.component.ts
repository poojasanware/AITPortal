import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  xyz:any;
  role:any;
  uname:any;
  constructor(private router:Router,
    private emp:CommonService) { }

    ngOnInit() {
    
      //this.xyz = localStorage.getItem('uname');
      // this.xyz = localStorage.getItem('first_name');
      this.role = localStorage.getItem('role');
      this.uname = localStorage.getItem('uname');
     //console.log(xyz);
    }
  addNews(){
    this.router.navigate(["addnews"]);
  }
  addUser(){
    this.router.navigate(["adduser"]);
  }
  addEvent(){
    this.router.navigate(["addevent"]);
  }
  showEvent(){
    this.router.navigate(["eventlist"]);
  }
}
