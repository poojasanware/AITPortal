import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Event } from 'src/app/classes/event';
import { CommonService } from 'src/app/services/common.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-updateevent',
  templateUrl: './updateevent.component.html',
  styleUrls: ['./updateevent.component.css']
})
export class UpdateeventComponent implements OnInit {
  event = new Event();
  id: any;
  data: any;


  constructor(private emp: CommonService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params.id;
    this.getEvent();
  }
  updateEvent(event: Event) {

    this.emp.updateEvent(this.event).subscribe(

      data => {
        console.log("updated");
        Swal.fire('Success', 'Updated Successfully', 'success');
        this.router.navigate(["commondashboard"]);
      },
      error => {
        console.log("error");

      }
    );
  }

  getEvent() {
    this.emp.getOneEvent(this.id).subscribe(
      res => {
        console.log(res);
        this.data = res;
        this.event = this.data;
      })
  }

}
