import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { News } from 'src/app/classes/news';
import { CommonService } from 'src/app/services/common.service';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-addnews',
  templateUrl: './addnews.component.html',
  styleUrls: ['./addnews.component.css']
})
export class AddnewsComponent implements OnInit {
  news = new News();


  constructor(private emp: CommonService, private router: Router, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.createForm();
  }


  createForm() {
    this.newsfrm = this.fb.group({
      title: ['', Validators.required],
      content: ['', Validators.required]
    });
  }


  newsfrm = new FormGroup({
    title: new FormControl(),
    content: new FormControl()
  })

  addNews() {
    this.emp.addNewsFromRemote(this.news).subscribe(

      data => {
        console.log("recevied");
        Swal.fire('Success', 'Successfully Saved', 'success');
        this.router.navigate(["commondashboard"]);
      },
      error => {
        console.log("error");
        Swal.fire('Error', 'Something Went Wrong', 'error');

      }
    )

  }

}
