import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { Event } from 'src/app/classes/event';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-addevent',
  templateUrl: './addevent.component.html',
  styleUrls: ['./addevent.component.css']
})
export class AddeventComponent implements OnInit {
  event = new Event();
  constructor(private emp: CommonService, private router: Router, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.createForm();
  }

  createForm() {
    this.eventfrm = this.fb.group({
      event: ['', Validators.required],
      description: ['', Validators.required],
      date: ['', Validators.required],

    });
  }


  eventfrm = new FormGroup({
    event: new FormControl(),
    description: new FormControl(),
    date: new FormControl()
  })

  addEvent() {
    this.emp.addEventFromRemote(this.event).subscribe(

      data => {
        if (this.eventfrm.valid) {
          console.log(this.eventfrm.value);
          console.log("recevied");
          Swal.fire('Success', 'Successfully Saved', 'success');
          this.router.navigate(["commondashboard"]);
        }
      },
      error => {
        console.log("error");
        Swal.fire('Error', 'Something Went Wrong', 'error');

      }
    )

  }

}
