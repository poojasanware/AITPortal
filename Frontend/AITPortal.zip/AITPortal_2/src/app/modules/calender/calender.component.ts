import { Component, OnInit } from '@angular/core';
import { CalendarOptions } from '@fullcalendar/angular';
import { DatePipe } from '@angular/common';
import { formatDate } from '@angular/common';
import { CommonService } from '../../services/common.service';


@Component({
  selector: 'app-calender',
  templateUrl: './calender.component.html',
  styleUrls: ['./calender.component.css']
})
export class CalenderComponent implements OnInit {
  allEvents: any;


  public calenderEvents: any = [];
  public obj: any = {}
  calendarOptions: CalendarOptions = {};

  constructor(private commonService: CommonService) { }

  ngOnInit() {
    this.commonService.getAllEvent().subscribe(data => {

      this.allEvents = data;
      console.log(data, "data");

      this.allEvents.forEach((element: any) => {
        this.obj = { id: String(element.id), title: element.event, date: element.date }
        this.calenderEvents.push(this.obj);

      });
      console.log(this.calenderEvents, "dataa");

    })
    setInterval(() => {
      this.calendarOptions = {
        initialView: 'dayGridMonth',
        weekends: true,

        events: this.calenderEvents,

      };

    }, 5000);

  }

}

