import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { News } from 'src/app/classes/news';
import { CommonService } from 'src/app/services/common.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {
  isEdit = false;
  news = new News();
  xyz: any;

  constructor(private emp: CommonService, private router: Router) { }
  lstnews: News[] = [];

  ngOnInit(): void {
    this.getAllNews();
    this.xyz = localStorage.getItem('role');
    console.log(this.xyz);

  }
  getAllNews() {
    this.emp.getAllNews().subscribe(
      data => {
        this.lstnews = data;
      }
    );
  }

  deleteNews(lstnews: News) {
    if (confirm('Are you sure to delete?')) {
      this.emp.deletNews(lstnews).subscribe(() => {
        Swal.fire('Success', 'Deleted Successfully', 'success');
        this.getAllNews();
      })
    }
  }
}
